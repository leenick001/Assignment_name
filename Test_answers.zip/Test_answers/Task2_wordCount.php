<?php

//split the words up

$words = explode ("Delphi was originally one of many codenames of a pre-release development tool project at Borland. 
Borland developer Danny Thorpe suggested the Delphi codename in reference to the Oracle at 
Delphi. One of the design goals of the product was to provide database connectivity to programmers 
as a key feature and a popular database package at the time was Oracle database; hence, If you 
want to talk to Oracle, go to Delphi. 
As development continued towards the first release, the Delphi codename gained popularity among 
the development team and beta testing group. However, the Borland marketing leadership preferred 
a functional product name over an iconic name and made preparations to release the product under 
the name 'Borland AppBuilder");
$result = array_combine($words, array_fill(0, count($words), 0));

//loop the resulting words
foreach($words as $word) {
    $result[$word]++;
}

foreach($result as $word => $count) {
    echo "There are $count instances of $word.\n";
}

?>